// Attention Circuits Control Laboratory - Atmel AVR firmware
// Top-level header.
// Written by Christopher Thomas.
// Copyright (c) 2018 by Vanderbilt University. This work is licensed under
// the Creative Commons Attribution-NonCommercial 4.0 International License.


//
// Includes

// Common things we'll always want to include.
#include <stdint.h>
#include <stdlib.h>
#include <avr/io.h>
#include <avr/pgmspace.h>
#include <avr/interrupt.h>
#include <util/atomic.h>


// Architecture-specific headers.

#ifdef __AVR_ATmega2560__
#include "neur-m2560.h"
#endif

#ifdef __AVR_ATmega328P__
#include "neur-m328p.h"
#endif

#ifdef __AVR_ATmega32U4__
#include "neur-m32u4.h"
#endif


//
// Functions


// Initialization functions.

// Initializes the MCU to a known-good state.
void MCU_Init(void);


// Real-time clock functions.

// Unhooks all timers and initializes the RTC timer.
// An RTC rate of 0 disables the RTC.
void Timer_Init(uint32_t mcu_hz, uint32_t rtc_hz);

// Clears the RTC timestamp.
void Timer_Reset();

// Reads the real-time clock timestamp.
uint32_t Timer_Query();

// Reads the real-time clock timestamp while within an ISR or other
// locked code. This avoids an ATOMIC_BLOCK call.
uint32_t Timer_Query_ISR();

// Specifies a user-defined function to call during timer interrupts.
// _All_ interrupts, not just timer interrupts, are disabled while this
// runs, so it has to return very quickly.
void Timer_RegisterCallback(void (*callback)(void));


// UART functions.

// Configures the primary UART for the specified baud rate.
// A baud rate of 0 turns it off.
// Which UART is primary is architecture-dependent.
void UART_Init(uint32_t mcu_hz, uint32_t baud_rate);

// Returns the actual baud rate set, or 0 if the UART is off.
uint32_t UART_QueryBaud(void);

// Returns a pointer to the next complete line of input, or NULL if no
// complete line has been received yet.
char *UART_GetNextLine(void);

// Tells the UART manager that we're done with the line we requested a
// pointer to.
void UART_DoneWithLine(void);

// Queues a string for UART transmission. This must be NULL-terminated.
// This blocks until any previous transmission has finished.
void UART_QueueSend(char *message);

// Queues a string from flash memory for UART transmission.
// Otherwise behaves as UART_QueueSend().
void UART_QueueSend_P(PGM_P message);

// Blocks until the transmission in progress (if any) completes.
// Granularity is several hundred clock cycles due to busy-wait padding.
// Interrupts are still handled during that time.
void UART_WaitForSendDone(void);

// Queries whether or not a transmission is in progress.
bool UART_IsSendInProgress(void);

// Turns empty line filtering on or off.
// This saves buffer space but feels less interactive to users.
bool UART_SetLineFiltering(bool new_state);


// Formatted printing functions.

// Single-character output.
void UART_PrintChar(char value);

// Formatted integers.
void UART_PrintUInt(uint32_t value);
void UART_PrintSInt(int32_t value);
void UART_PrintHex32(uint32_t value);
void UART_PrintHex16(uint16_t value);
void UART_PrintHex8(uint8_t value);


// FIXME - ADC functions go here.


//
// This is the end of the file.
