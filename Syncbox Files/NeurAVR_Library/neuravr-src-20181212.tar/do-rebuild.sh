#!/bin/bash
# Attention Circuits Control Laboratory - Atmel AVR firmware
# Rebuild script.
# Written by Christopher Thomas.
# Copyright (c) 2018 by Vanderbilt University. This work is licensed under
# the Creative Commons Attribution-NonCommercial 4.0 International License.


# Configuration.

TOPDIR=`pwd`

CFLAGS="-I`pwd`/include -Os -c -fno-exceptions"

read -d '' ARCHLIST <<-"Endofblock"
	m328p
	m2560
Endofblock


# Copy headers.
# These need to be in place before compiling.

rm -rf include
mkdir include
cp core/*.h include
for ARCHDIR in $ARCHLIST
do
  cp ${ARCHDIR}/neur-${ARCHDIR}*.h include
done


# Build each of the architectures.

rm -rf lib
mkdir lib

for ARCHDIR in $ARCHLIST
do
  # Banner.
  echo "-- $ARCHDIR"

  ARCHDEF=`cat ${ARCHDIR}/ARCHDEF`
  ARCHTARGET=`cat ${ARCHDIR}/ARCHTARGET`

# FIXME - Diagnostics
#echo ".. Macro: ${ARCHDEF}  Target mcu: ${ARCHTARGET}"

  # Rebuild core.

  cd ${TOPDIR}/core

  rm -f *.o
  for CFILE in *.cpp
  do
    OFILE=`echo $CFILE|sed -e "s/cpp/o/"`
# FIXME - Diagnostics.
echo ".. core/${CFILE}"
echo    avr-gcc -mmcu=${ARCHTARGET} -D${ARCHDEF} $CFLAGS -o $OFILE $CFILE
    avr-gcc -mmcu=${ARCHTARGET} -D${ARCHDEF} $CFLAGS -o $OFILE $CFILE
  done

  # Build architecture-specific routines.

  cd ${TOPDIR}/${ARCHDIR}

  rm -f *.o
  for CFILE in *.cpp
  do
# FIXME - Diagnostics.
echo ".. ${ARCHDIR}/${CFILE}"
    OFILE=`echo $CFILE|sed -e "s/cpp/o/"`
echo    avr-gcc -mmcu=${ARCHTARGET} -D${ARCHDEF} $CFLAGS -o $OFILE $CFILE
    avr-gcc -mmcu=${ARCHTARGET} -D${ARCHDEF} $CFLAGS -o $OFILE $CFILE
  done

  # Assemble the library.

  cd ${TOPDIR}
echo  avr-ar -rs lib/libneur-${ARCHDIR}.a core/*.o ${ARCHDIR}/*.o
  avr-ar -rs lib/libneur-${ARCHDIR}.a core/*.o ${ARCHDIR}/*.o

  # Clean up.
  rm -f core/*.o
  rm -f ${ARCHDIR}/*.o
done

# Ending banner.
echo "-- Done."


# This is the end of the file.
