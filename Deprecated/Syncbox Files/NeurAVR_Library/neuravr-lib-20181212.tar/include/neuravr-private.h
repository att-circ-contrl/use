// Attention Circuits Control Laboratory - Atmel AVR firmware
// Comon core header.
// Written by Christopher Thomas.
// Copyright (c) 2018 by Vanderbilt University. This work is licensed under
// the Creative Commons Attribution-NonCommercial 4.0 International License.


//
// Variables


// Real-time clock variables.

extern volatile uint32_t rtc_timestamp;
extern void (*rtc_usercallback)(void);

// No shared UART variables.

// FIXME - ADC variables go here.


//
// Functions


// Real-time clock functions.

// No additional RTC functions.


// UART functions.

// This initializes buffer-handling. It should be called by UART_Init().
// The caller is responsible for any needed locking.
void UART_InitBuffers_ISR(void);

// These are buffer interaction handlers called from within ISRs.
void UART_HandleRecvChar_ISR(char recvchar);
bool UART_GetNextSendChar_ISR(char &sendchar);

// This is a transmission-start hook called after a string is queued.
// It re-enables need-character interrupts if they aren't aready enabled.
// The caller is responsible for any needed locking.
void UART_EnableTransmit_ISR(void);


// FIXME - ADC functions go here.


//
// This is the end of the file.
