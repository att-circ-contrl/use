// Attention Circuits Control Laboratory - USE SyncBox project
// Host command parsing
// Written by Christopher Thomas.
// Copyright (c) 2018 by Vanderbilt University. This work is licensed under
// the Creative Commons Attribution-NonCommercial 4.0 International License.


//
// Functions


// Initializes the parser.
void InitParser();


// Entry point for handling text from the host.
// The raw string must be either NULL or guaranteed NULL-terminated.

void ProcessInputLine(char *thisline);



//
// This is the end of the file.
