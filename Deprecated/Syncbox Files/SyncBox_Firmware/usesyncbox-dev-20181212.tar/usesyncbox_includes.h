// Attention Circuits Control laboratory - USE SyncBox project
// Top-level include file.
// Written by Christopher Thomas.
// Copyright (c) 2018 by Vanderbilt University. This work is licensed under
// the Creative Commons Attribution-NonCommercial 4.0 International License.


//
// Includes


// Platform-specific includes.
// If we're in the Arduino IDE, use "Arduino.h".
// If we're building manually with the NeurAVR library, use "neuravr.h".

#ifdef USE_NEURAVR

#include "neuravr.h"

#else

#include "Arduino.h"

#endif


// Project-specific includes.
#include <util/atomic.h>
#include "usesyncbox_config.h"
#include "usesyncbox_timer.h"
#include "usesyncbox_adc.h"
#include "usesyncbox_light.h"
#include "usesyncbox_io.h"
#include "usesyncbox_events.h"
#include "usesyncbox_parse.h"
#include "usesyncbox_host.h"
#include "usesyncbox_main.h"


//
// This is the end of the file.
